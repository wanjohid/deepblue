﻿
Microsoft Visual Studio Solution File, Format Version 11.00
# Visual Studio 2010
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "GuessTheWord", "GuessTheWord.csproj", "{FFB863B8-7861-4BBB-BE68-EFC3E33CA610}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x86 = Debug|x86
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{FFB863B8-7861-4BBB-BE68-EFC3E33CA610}.Debug|x86.ActiveCfg = Debug|x86
		{FFB863B8-7861-4BBB-BE68-EFC3E33CA610}.Debug|x86.Build.0 = Debug|x86
		{FFB863B8-7861-4BBB-BE68-EFC3E33CA610}.Release|x86.ActiveCfg = Release|x86
		{FFB863B8-7861-4BBB-BE68-EFC3E33CA610}.Release|x86.Build.0 = Release|x86
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal
