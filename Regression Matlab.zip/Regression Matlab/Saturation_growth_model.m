
function [a,b,r]=Saturation_growth_model(x,y)
% Saturation growth Model
x2=1/x;
y2=1/y;
n=length(x2);
[S_a0,S_a1,r] = Linear_Regression(n,x2,y2);
a=1/S_a0;
b=a*S_a1;
Y=(a.*x)./(b+x);

plot(x,Y);
xlabel('x');
ylabel('y');
title('Saturation Growth Rate Models')
legend('Saturated')
hold on;
scatter(x,y);
grid on;
end