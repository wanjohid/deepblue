clc%clears screen
clear all%clears history
close all%closes all files
format long
x=[0.75,2,3,4,6,8,8.5];
y=[1.2,1.95,2,2.4,2.4,2.7,2.6];
[a0,a1=,R_2]=func1(x,y)

function[a0,a,R_2]=func1(x,y)
A=[x(:) ones(numel(x),1)];
b=y(:);
C=A\b;
a1=C(1);
a0=C(2);
SSR=sum((a1*x+a0-y).^2);
SST=sum((y-mean(y)).^2);
R_2=1-SSR/SST;
end