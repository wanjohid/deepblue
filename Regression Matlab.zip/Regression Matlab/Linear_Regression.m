function [a0,a1,r2] = Linear_Regression(n,x,y)
Xave = sum(x)/n;
Yave = sum(y)/n;
Sxy = 0;
Sxx = 0;
St =0;
Sr=0;

for i=1:n
Sxy = Sxy + (x(i)*y(i)) - Xave*Yave;
Sxx = Sxx + (x(i)^2) - Xave^2;
end

a1= Sxy/Sxx;
a0= Yave -1*a1*Xave;

Y = a0 +a1*x; %% Linear model


for i=1:n
St = St+((y(i)-Yave)^2);
Sr = Sr+((Y(i) - y(i))^2);
end

r2=(St - Sr)/St;
end