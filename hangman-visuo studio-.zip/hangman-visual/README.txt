A Hangman project built on C# and WPF using .NETCORE

>Open the hangman master folder
>Click on the hangman
>Click on bin
>Open Debug 
>Run the hangman-application